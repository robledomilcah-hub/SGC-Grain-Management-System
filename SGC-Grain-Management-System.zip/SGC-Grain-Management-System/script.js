// SGC classroom prototype - data is saved in this browser using localStorage.
const defaultData = {
  farmers:[{id:"F001",name:"Maria Santos",contact:"09123456789"},{id:"F002",name:"Juan Dela Cruz",contact:"09987654321"},{id:"F003",name:"Ana Reyes",contact:"09112223334"}],
  grains:[{id:"G001",name:"Rice",stock:2500},{id:"G002",name:"Corn",stock:1800},{id:"G003",name:"Wheat",stock:900}],
  deliveries:[],orders:[]
};
let data = JSON.parse(localStorage.getItem("sgcData")) || defaultData;
const $ = id => document.getElementById(id);
const today = new Date().toISOString().slice(0,10);
$("delivery-date").value = today;
function save(){localStorage.setItem("sgcData",JSON.stringify(data));renderAll();}
function totalStock(){return data.grains.reduce((sum,g)=>sum+g.stock,0);}
function escapeHTML(value){return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function grainOptions(){return data.grains.map(g=>`<option value="${g.id}">${g.name}</option>`).join("");}
function setupForms(){
  $("farmer-options").innerHTML=data.farmers.map(f=>`<option value="${f.id} - ${f.name}"></option>`).join("");
  $("delivery-grain").innerHTML=grainOptions();$("order-grain").innerHTML=grainOptions();
}
function showPage(page){
  document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===page));
  document.querySelectorAll(".nav-link").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  const titles={dashboard:"Dashboard",deliveries:"Record Delivery",inventory:"Inventory",orders:"Buyer Orders",reports:"Monthly Reports"};
  $("page-title").textContent=titles[page]||"Dashboard";
  renderAll();
}
document.querySelectorAll(".nav-link").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.page)));
document.querySelectorAll("[data-goto]").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.goto)));
function renderAll(){
  setupForms();
  $("total-stock").textContent=totalStock().toLocaleString()+" kg";
  $("total-deliveries").textContent=data.deliveries.length;
  $("total-orders").textContent=data.orders.length;
  $("total-farmers").textContent=data.farmers.length;
  const max=Math.max(...data.grains.map(g=>g.stock),1);
  $("dashboard-inventory").innerHTML=data.grains.map(g=>`<div class="inventory-row"><span>${escapeHTML(g.name)}</span><div class="bar"><span style="width:${Math.max(2,g.stock/max*100)}%"></span></div><b>${g.stock.toLocaleString()} kg</b></div>`).join("");
  const activities=[
    ...data.deliveries.map(d=>({type:"Delivery",detail:`${d.farmer} · ${d.grain} · ${d.quantity.toLocaleString()} kg`,date:d.date,status:"Recorded"})),
    ...data.orders.map(o=>({type:"Buyer Order",detail:`${o.buyer} · ${o.grain} · ${o.quantity.toLocaleString()} kg`,date:o.date,status:o.status}))
  ].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,5);
  $("recent-activities").innerHTML=activities.length?activities.map(a=>`<tr><td>${a.type}</td><td>${escapeHTML(a.detail)}</td><td>${a.date}</td><td><span class="status">${a.status}</span></td></tr>`).join(""):`<tr><td colspan="4">No activity yet. Add a delivery or buyer order to get started.</td></tr>`;
  $("delivery-history").innerHTML=data.deliveries.length?[...data.deliveries].reverse().map(d=>`<tr><td>${d.id}</td><td>${escapeHTML(d.farmer)}</td><td>${escapeHTML(d.grain)}</td><td>${d.quantity.toLocaleString()} kg</td><td>${d.date}</td></tr>`).join(""):`<tr><td colspan="5">No deliveries recorded yet.</td></tr>`;
  $("inventory-cards").innerHTML=data.grains.map(g=>`<article class="grain-card"><div class="grain-emoji">🌾</div><h3>${escapeHTML(g.name)}</h3><strong>${g.stock.toLocaleString()} kg</strong><small>Available stock</small></article>`).join("");
  $("inventory-table").innerHTML=data.grains.map(g=>`<tr><td>${g.id}</td><td>${escapeHTML(g.name)}</td><td>${g.stock.toLocaleString()} kg</td><td><span class="status">${g.stock>0?"Available":"Out of stock"}</span></td></tr>`).join("");
  $("order-history").innerHTML=data.orders.length?[...data.orders].reverse().map(o=>`<tr><td>${o.id}</td><td>${escapeHTML(o.buyer)}</td><td>${escapeHTML(o.grain)}</td><td>${o.quantity.toLocaleString()} kg</td><td>${o.date}</td><td><span class="status">${o.status}</span></td><td><button class="text-button" onclick="showReceipt('${o.id}')">View slip</button></td></tr>`).join(""):`<tr><td colspan="7">No buyer orders recorded yet.</td></tr>`;
  const received=g=>data.deliveries.filter(d=>d.grainId===g.id).reduce((s,d)=>s+d.quantity,0);
  const ordered=g=>data.orders.filter(o=>o.grainId===g.id).reduce((s,o)=>s+o.quantity,0);
  $("report-deliveries").textContent=data.deliveries.length;
  $("report-received").textContent=data.deliveries.reduce((s,d)=>s+d.quantity,0).toLocaleString()+" kg";
  $("report-ordered").textContent=data.orders.reduce((s,o)=>s+o.quantity,0).toLocaleString()+" kg";
  $("report-table").innerHTML=data.grains.map(g=>`<tr><td>${escapeHTML(g.name)}</td><td>${received(g).toLocaleString()} kg</td><td>${ordered(g).toLocaleString()} kg</td><td>${g.stock.toLocaleString()} kg</td></tr>`).join("");
  updateStockHint();
}
$("delivery-form").addEventListener("submit",e=>{
  e.preventDefault();
  const farmerInput=$("farmer-search").value.trim();
  const farmer=data.farmers.find(f=>farmerInput.toLowerCase()===f.id.toLowerCase()||farmerInput.toLowerCase()===f.name.toLowerCase()||farmerInput.toLowerCase()===`${f.id} - ${f.name}`.toLowerCase());
  const grain=data.grains.find(g=>g.id===$("delivery-grain").value);
  const quantity=Number($("delivery-quantity").value),date=$("delivery-date").value;
  if(!farmer){message("delivery-message","Farmer not found. Use F001, F002, F003 or a registered name.","error");return;}
  if(!grain||quantity<=0||!Number.isFinite(quantity)){message("delivery-message","Please enter a valid quantity.","error");return;}
  data.deliveries.push({id:"DEL"+String(data.deliveries.length+1).padStart(3,"0"),farmer:farmer.name,farmerId:farmer.id,grain:grain.name,grainId:grain.id,quantity,date});
  grain.stock+=quantity;save();$("delivery-form").reset();$("delivery-date").value=today;
  message("delivery-message","Delivery saved! Inventory has been updated.","success");
});
function message(id,text,type){$(id).textContent=text;$(id).className="form-message "+type;}
function updateStockHint(){const g=data.grains.find(x=>x.id===$("order-grain").value);$("stock-hint").textContent=g?`Available stock: ${g.stock.toLocaleString()} kg`:"Select a grain to view available stock.";}
$("order-grain").addEventListener("change",updateStockHint);
$("order-form").addEventListener("submit",e=>{
  e.preventDefault();const buyer=$("buyer-name").value.trim(),grain=data.grains.find(g=>g.id===$("order-grain").value),quantity=Number($("order-quantity").value);
  if(!buyer||!grain||quantity<=0){message("order-message","Please complete all fields with valid information.","error");return;}
  if(quantity>grain.stock){message("order-message",`Order rejected. Only ${grain.stock.toLocaleString()} kg of ${grain.name} is available.`,"error");return;}
  const order={id:"ORD"+String(data.orders.length+1).padStart(3,"0"),buyer,grain:grain.name,grainId:grain.id,quantity,date:today,status:"Confirmed"};
  data.orders.push(order);grain.stock-=quantity;save();$("order-form").reset();updateStockHint();message("order-message","Order confirmed! A printable receipt is ready.","success");showReceipt(order.id);
});
function showReceipt(id){
  const o=data.orders.find(x=>x.id===id);if(!o)return;
  $("receipt-content").innerHTML=`<div class="receipt-head"><div class="logo">🌾</div><h2>Sintang Grains Cooperative</h2><p>BUYER ORDER CONFIRMATION</p></div><div class="receipt-line"><span>Order Number</span><b>${o.id}</b></div><div class="receipt-line"><span>Buyer</span><b>${escapeHTML(o.buyer)}</b></div><div class="receipt-line"><span>Grain Type</span><b>${escapeHTML(o.grain)}</b></div><div class="receipt-line"><span>Quantity</span><b>${o.quantity.toLocaleString()} kg</b></div><div class="receipt-line"><span>Date</span><b>${o.date}</b></div><div class="receipt-line"><span>Status</span><b>${o.status}</b></div><p style="text-align:center;font-size:10px;color:#9a8792;margin-top:18px">Thank you for doing business with SGC.</p>`;
  $("receipt-modal").classList.remove("hidden");
}
window.showReceipt=showReceipt;
$("close-receipt").addEventListener("click",()=>$("receipt-modal").classList.add("hidden"));
$("receipt-modal").addEventListener("click",e=>{if(e.target.id==="receipt-modal")$("receipt-modal").classList.add("hidden");});
$("print-receipt").addEventListener("click",()=>{const content=$("receipt-content").innerHTML;const w=window.open("","_blank","width=600,height=700");w.document.write(`<html><head><title>SGC Receipt</title><style>body{font-family:Arial;padding:30px;color:#443b49;max-width:500px;margin:auto}.receipt-head{text-align:center;border-bottom:1px dashed #ccc;padding-bottom:15px}.receipt-line{display:flex;justify-content:space-between;padding:12px 0;border-bottom:1px solid #eee;font-size:14px}</style></head><body>${content}</body></html>`);w.document.close();w.print();});
$("print-report").addEventListener("click",()=>window.print());
renderAll();
